﻿using Boekingssysteem.Models;
using System.Collections.Generic;

namespace Boekingssysteem.ViewModels
{
    public class PersoonListViewModel
    {
        public List<Persoon> Personen { get; set; }
    }
}
